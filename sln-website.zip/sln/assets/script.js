const PRODUCTS = [
  { name: "6-Burner Gas Range with Oven", image: "https://drive.google.com/thumbnail?id=1-6miFI3nh6CO-gLmxyh4ppnDrYQT7SHy&sz=w1000" },
  { name: "Single Burner Commercial Gas Range", image: "https://drive.google.com/thumbnail?id=17jOHngOTdqxnvgRwuZoxUsbDjw8s5m4F&sz=w1000" },
  { name: "Shawarma Machine", image: "" },
  { name: "Rice Vessel", image: "" },
  { name: "Flat Grill / Tawa", image: "" },
  { name: "Two Burner", image: "" },
  { name: "Single Sink Unit", image: "" },
  { name: "Two Sink Unit", image: "" },
  { name: "Three Sink Unit", image: "" },
  { name: "Commercial Dishwasher", image: "" },
  { name: "Work Table", image: "" },
  { name: "Display Counter", image: "" },
  { name: "Bain Marie", image: "" },
  { name: "Exhaust Hood", image: "" },
  { name: "Gas Line", image: "" },
  { name: "Custom / Multiple", image: "" },
];

let selectedProduct = "";

function buildProductGrid() {
  const grid = document.getElementById("productGrid");
  if (!grid) return;
  PRODUCTS.forEach(p => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "product-btn";
    btn.onclick = () => {
      document.querySelectorAll(".product-btn").forEach(b => b.classList.remove("selected"));
      btn.classList.add("selected");
      selectedProduct = p.name;
    };
    if (p.image) {
      btn.innerHTML = `<img src="${p.image}" alt="${p.name}"><span>${p.name}</span>`;
    } else {
      btn.innerHTML = `<div class="placeholder">📦</div><span>${p.name}</span>`;
    }
    grid.appendChild(btn);
  });
}

function openPopup() {
  document.getElementById("popup").classList.add("active");
}

function closePopup() {
  document.getElementById("popup").classList.remove("active");
  localStorage.setItem("lead_popup_seen", "true");
}

function initLeadForm() {
  buildProductGrid();

  // Show popup after 10 seconds (only once per visitor)
  if (!localStorage.getItem("lead_popup_seen")) {
    setTimeout(() => {
      document.getElementById("popup").classList.add("active");
    }, 10000);
  }

  const form = document.getElementById("leadForm");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("submitBtn");
    btn.disabled = true;
    btn.textContent = "Submitting...";

    const data = {
      name: document.getElementById("name").value,
      phone: document.getElementById("phone").value,
      email: document.getElementById("email").value,
      product_interested: selectedProduct,
      requirements: document.getElementById("requirements").value,
      page_source: window.location.pathname,
      status: "new",
    };

    // Submit to Supabase
    try {
      const res = await fetch("https://pvymfafulsurpggfpmrp.supabase.co/rest/v1/leads", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "apikey": "YOUR_SUPABASE_ANON_KEY", // ← Replace with your anon key
          "Authorization": "Bearer YOUR_SUPABASE_ANON_KEY", // ← Replace with your anon key
        },
        body: JSON.stringify(data),
      });

      if (!res.ok) throw new Error("Failed");

      document.getElementById("formBody").style.display = "none";
      document.getElementById("successBody").style.display = "block";
      setTimeout(() => closePopup(), 2500);
    } catch (err) {
      alert("Something went wrong. Please call us instead!");
      btn.disabled = false;
      btn.textContent = "Submit Request";
    }
  });
}

document.addEventListener("DOMContentLoaded", initLeadForm);
